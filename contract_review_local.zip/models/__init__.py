"""
Models package for AI Contract Review application.

This package contains Pydantic models for data validation and serialization.
"""
