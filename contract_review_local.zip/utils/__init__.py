"""
Utilities package for AI Contract Review application.

This package contains utility functions for validation, formatting, and other helper functions.
"""
